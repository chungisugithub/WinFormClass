﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : System.Windows.Forms.Form
    {
        SqlConnection conn;
        int tempID;
        public Form1()
        {
            InitializeComponent();
            conn = new SqlConnection(@"Server=DESKTOP-MSTKBUJ\SQLEXPRESS01;Database=Students;User Id=sa;Password=1234");
        }


        private void show_Click(object sender, EventArgs e)
        {
            display();
        }
        private void display()
        {
            SqlDataAdapter sqlAdapter = new SqlDataAdapter("Select * from Students", conn);
            DataTable dt = new DataTable();
            sqlAdapter.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void insert_click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("insert into Students (Name, Age, Location, Gender) values( @p1, @p2, @p3, @p4 );", conn);
            conn.Open();
            cmd.Parameters.AddWithValue("@p1", textBox2.Text);
            cmd.Parameters.AddWithValue("@p2", int.Parse(textBox4.Text));
            cmd.Parameters.AddWithValue("@p3", textBox3.Text);
            cmd.Parameters.AddWithValue("@p4", comboBox1.Text);

            cmd.ExecuteNonQuery();
            display();
            MessageBox.Show("입력되었습니다. ");

            conn.Close();
        }

        private void update_Click(object sender, EventArgs e)
        {
            SqlCommand cmd;
            conn.Open();
            string sqlQuery = "update Students set Name = @p1, Age = @p2, Location = @p3, Gender = @p4 where ID = " + tempID + "";

            cmd = new SqlCommand(sqlQuery, conn);
            cmd.Parameters.AddWithValue("@p1", textBox2.Text);
            cmd.Parameters.AddWithValue("@p2", int.Parse(textBox4.Text));
            cmd.Parameters.AddWithValue("@p3", textBox3.Text);
            cmd.Parameters.AddWithValue("@p4", comboBox1.Text);

            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();
            conn.Close();
            display();
            clearFields();
            MessageBox.Show("수정되었습니다.");
        }

        private void delete_Click(object sender, EventArgs e)
        {
            SqlCommand cmd;
            conn.Open();
            for(int i=0; i < dataGridView1.Rows.Count; i++)
            {
                DataGridViewRow delRow = dataGridView1.Rows[i];
                if(delRow.Selected == true)
                {
                    string sqlQuery = "Delete from Students where id = " + dataGridView1.Rows[i].Cells[4].Value + "";
                    cmd = new SqlCommand(sqlQuery, conn);
                    cmd.CommandType = CommandType.Text;
                    cmd.ExecuteNonQuery();
                }
            }

            conn.Close();
            display();
            MessageBox.Show("삭제되었습니다.");
        }

        private void tbupdate(object sender, MouseEventArgs e)
        {
            if(dataGridView1.Rows.Count > 0)
            {
                tempID = int.Parse(dataGridView1.SelectedRows[0].Cells[4].Value.ToString());

                textBox2.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                textBox3.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                textBox4.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
                comboBox1.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            }
        }

        private void clearFields()
        {
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            comboBox1.Text = " ";
        }
    }
}
